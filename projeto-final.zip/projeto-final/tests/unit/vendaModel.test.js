const { expect } = require('chai');
const Venda = require('../../src/models/Venda');
const Cliente = require('../../src/models/Cliente');
const database = require('../../src/database/database');

describe('Venda Model - Testes Unitários', function() {
    // Configurar timeout para operações de banco
    this.timeout(5000);

    let clienteId;

    before(function(done) {
        // Inicializar banco de dados de teste
        database.init();
        setTimeout(done, 1000); // Aguardar inicialização
    });

    beforeEach(async function() {
        // Limpar tabelas antes de cada teste
        await new Promise((resolve) => {
            database.getDb().run('DELETE FROM vendas', resolve);
        });
        await new Promise((resolve) => {
            database.getDb().run('DELETE FROM clientes', resolve);
        });

        // Criar um cliente para usar nos testes
        const cliente = await Cliente.create({
            nome: 'João Silva',
            email: 'joao@email.com',
            telefone: '11999999999'
        });
        clienteId = cliente.id;
    });

    describe('Validação de dados', function() {
        it('deve retornar erro quando cliente_id está vazio', function() {
            const vendaData = {
                cliente_id: '',
                data_venda: '2025-07-20',
                valor_total: 100.50,
                descricao: 'Teste'
            };

            const errors = Venda.validate(vendaData);
            expect(errors).to.include('Cliente é obrigatório');
        });

        it('deve retornar erro quando data_venda está vazia', function() {
            const vendaData = {
                cliente_id: 1,
                data_venda: '',
                valor_total: 100.50,
                descricao: 'Teste'
            };

            const errors = Venda.validate(vendaData);
            expect(errors).to.include('Data da venda é obrigatória');
        });

        it('deve retornar erro quando valor_total é inválido', function() {
            const vendaData = {
                cliente_id: 1,
                data_venda: '2025-07-20',
                valor_total: 0,
                descricao: 'Teste'
            };

            const errors = Venda.validate(vendaData);
            expect(errors).to.include('Valor total deve ser um número positivo');
        });

        it('deve retornar erro quando valor_total não é número', function() {
            const vendaData = {
                cliente_id: 1,
                data_venda: '2025-07-20',
                valor_total: 'abc',
                descricao: 'Teste'
            };

            const errors = Venda.validate(vendaData);
            expect(errors).to.include('Valor total deve ser um número positivo');
        });

        it('deve retornar array vazio quando dados são válidos', function() {
            const vendaData = {
                cliente_id: 1,
                data_venda: '2025-07-20',
                valor_total: 100.50,
                descricao: 'Teste'
            };

            const errors = Venda.validate(vendaData);
            expect(errors).to.be.an('array').that.is.empty;
        });
    });

    describe('Operações CRUD', function() {
        it('deve criar uma nova venda', async function() {
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            const venda = await Venda.create(vendaData);
            
            expect(venda).to.have.property('id');
            expect(venda.cliente_id).to.equal(vendaData.cliente_id);
            expect(venda.data_venda).to.equal(vendaData.data_venda);
            expect(venda.valor_total).to.equal(vendaData.valor_total);
            expect(venda.descricao).to.equal(vendaData.descricao);
        });

        it('deve buscar todas as vendas com informações do cliente', async function() {
            // Criar algumas vendas
            await Venda.create({
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda 1'
            });

            await Venda.create({
                cliente_id: clienteId,
                data_venda: '2025-07-21',
                valor_total: 200.00,
                descricao: 'Venda 2'
            });

            const vendas = await Venda.findAll();
            expect(vendas).to.be.an('array').with.length(2);
            expect(vendas[0]).to.have.property('cliente_nome');
            expect(vendas[0]).to.have.property('cliente_email');
            expect(vendas[0]).to.have.property('valor_total');
        });

        it('deve buscar venda por ID com informações do cliente', async function() {
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            const vendaCriada = await Venda.create(vendaData);
            const vendaEncontrada = await Venda.findById(vendaCriada.id);

            expect(vendaEncontrada).to.not.be.null;
            expect(vendaEncontrada.valor_total).to.equal(vendaData.valor_total);
            expect(vendaEncontrada.cliente_nome).to.equal('João Silva');
            expect(vendaEncontrada.cliente_email).to.equal('joao@email.com');
        });

        it('deve retornar null quando venda não existe', async function() {
            const venda = await Venda.findById(999);
            expect(venda).to.be.undefined;
        });

        it('deve atualizar uma venda', async function() {
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            const vendaCriada = await Venda.create(vendaData);
            
            const dadosAtualizados = {
                cliente_id: clienteId,
                data_venda: '2025-07-21',
                valor_total: 200.00,
                descricao: 'Venda atualizada'
            };

            const vendaAtualizada = await Venda.update(vendaCriada.id, dadosAtualizados);

            expect(vendaAtualizada.data_venda).to.equal(dadosAtualizados.data_venda);
            expect(vendaAtualizada.valor_total).to.equal(dadosAtualizados.valor_total);
            expect(vendaAtualizada.descricao).to.equal(dadosAtualizados.descricao);
        });

        it('deve lançar erro ao tentar atualizar venda inexistente', async function() {
            const dadosAtualizados = {
                cliente_id: clienteId,
                data_venda: '2025-07-21',
                valor_total: 200.00,
                descricao: 'Venda atualizada'
            };

            try {
                await Venda.update(999, dadosAtualizados);
                expect.fail('Deveria ter lançado erro');
            } catch (error) {
                expect(error.message).to.equal('Venda não encontrada');
            }
        });

        it('deve deletar uma venda', async function() {
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            const vendaCriada = await Venda.create(vendaData);
            const resultado = await Venda.delete(vendaCriada.id);

            expect(resultado).to.have.property('message');
            expect(resultado.message).to.equal('Venda deletada com sucesso');

            // Verificar se foi realmente deletada
            const vendaEncontrada = await Venda.findById(vendaCriada.id);
            expect(vendaEncontrada).to.be.undefined;
        });

        it('deve lançar erro ao tentar deletar venda inexistente', async function() {
            try {
                await Venda.delete(999);
                expect.fail('Deveria ter lançado erro');
            } catch (error) {
                expect(error.message).to.equal('Venda não encontrada');
            }
        });

        it('deve buscar vendas por cliente', async function() {
            // Criar vendas para o cliente
            await Venda.create({
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda 1'
            });

            await Venda.create({
                cliente_id: clienteId,
                data_venda: '2025-07-21',
                valor_total: 200.00,
                descricao: 'Venda 2'
            });

            const vendas = await Venda.findByClienteId(clienteId);
            expect(vendas).to.be.an('array').with.length(2);
            expect(vendas[0].cliente_id).to.equal(clienteId);
            expect(vendas[1].cliente_id).to.equal(clienteId);
        });
    });
});

