const { expect } = require('chai');
const Cliente = require('../../src/models/Cliente');
const database = require('../../src/database/database');

describe('Cliente Model - Testes Unitários', function() {
    // Configurar timeout para operações de banco
    this.timeout(5000);

    before(function(done) {
        // Inicializar banco de dados de teste
        database.init();
        setTimeout(done, 1000); // Aguardar inicialização
    });

    beforeEach(function(done) {
        // Limpar tabela antes de cada teste
        database.getDb().run('DELETE FROM clientes', done);
    });

    describe('Validação de dados', function() {
        it('deve retornar erro quando nome está vazio', function() {
            const clienteData = {
                nome: '',
                email: 'teste@email.com',
                telefone: '11999999999'
            };

            const errors = Cliente.validate(clienteData);
            expect(errors).to.include('Nome é obrigatório');
        });

        it('deve retornar erro quando email está vazio', function() {
            const clienteData = {
                nome: 'João Silva',
                email: '',
                telefone: '11999999999'
            };

            const errors = Cliente.validate(clienteData);
            expect(errors).to.include('Email é obrigatório');
        });

        it('deve retornar erro quando email tem formato inválido', function() {
            const clienteData = {
                nome: 'João Silva',
                email: 'email-invalido',
                telefone: '11999999999'
            };

            const errors = Cliente.validate(clienteData);
            expect(errors).to.include('Email deve ter um formato válido');
        });

        it('deve retornar array vazio quando dados são válidos', function() {
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            const errors = Cliente.validate(clienteData);
            expect(errors).to.be.an('array').that.is.empty;
        });
    });

    describe('Operações CRUD', function() {
        it('deve criar um novo cliente', async function() {
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            const cliente = await Cliente.create(clienteData);
            
            expect(cliente).to.have.property('id');
            expect(cliente.nome).to.equal(clienteData.nome);
            expect(cliente.email).to.equal(clienteData.email);
            expect(cliente.telefone).to.equal(clienteData.telefone);
        });

        it('deve buscar todos os clientes', async function() {
            // Criar alguns clientes
            await Cliente.create({
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            });

            await Cliente.create({
                nome: 'Maria Santos',
                email: 'maria@email.com',
                telefone: '11888888888'
            });

            const clientes = await Cliente.findAll();
            expect(clientes).to.be.an('array').with.length(2);
            expect(clientes[0]).to.have.property('nome');
            expect(clientes[0]).to.have.property('email');
        });

        it('deve buscar cliente por ID', async function() {
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            const clienteCriado = await Cliente.create(clienteData);
            const clienteEncontrado = await Cliente.findById(clienteCriado.id);

            expect(clienteEncontrado).to.not.be.null;
            expect(clienteEncontrado.nome).to.equal(clienteData.nome);
            expect(clienteEncontrado.email).to.equal(clienteData.email);
        });

        it('deve retornar null quando cliente não existe', async function() {
            const cliente = await Cliente.findById(999);
            expect(cliente).to.be.undefined;
        });

        it('deve atualizar um cliente', async function() {
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            const clienteCriado = await Cliente.create(clienteData);
            
            const dadosAtualizados = {
                nome: 'João Santos',
                email: 'joao.santos@email.com',
                telefone: '11888888888'
            };

            const clienteAtualizado = await Cliente.update(clienteCriado.id, dadosAtualizados);

            expect(clienteAtualizado.nome).to.equal(dadosAtualizados.nome);
            expect(clienteAtualizado.email).to.equal(dadosAtualizados.email);
            expect(clienteAtualizado.telefone).to.equal(dadosAtualizados.telefone);
        });

        it('deve lançar erro ao tentar atualizar cliente inexistente', async function() {
            const dadosAtualizados = {
                nome: 'João Santos',
                email: 'joao.santos@email.com',
                telefone: '11888888888'
            };

            try {
                await Cliente.update(999, dadosAtualizados);
                expect.fail('Deveria ter lançado erro');
            } catch (error) {
                expect(error.message).to.equal('Cliente não encontrado');
            }
        });

        it('deve deletar um cliente', async function() {
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            const clienteCriado = await Cliente.create(clienteData);
            const resultado = await Cliente.delete(clienteCriado.id);

            expect(resultado).to.have.property('message');
            expect(resultado.message).to.equal('Cliente deletado com sucesso');

            // Verificar se foi realmente deletado
            const clienteEncontrado = await Cliente.findById(clienteCriado.id);
            expect(clienteEncontrado).to.be.undefined;
        });

        it('deve lançar erro ao tentar deletar cliente inexistente', async function() {
            try {
                await Cliente.delete(999);
                expect.fail('Deveria ter lançado erro');
            } catch (error) {
                expect(error.message).to.equal('Cliente não encontrado');
            }
        });
    });
});

