const request = require('supertest');
const { expect } = require('chai');
const app = require('../../app');
const database = require('../../src/database/database');

describe('Cliente API - Testes de Integração', function() {
    // Configurar timeout para operações de banco
    this.timeout(10000);

    before(function(done) {
        // Inicializar banco de dados de teste
        database.init();
        setTimeout(done, 2000); // Aguardar inicialização
    });

    beforeEach(function(done) {
        // Limpar tabela antes de cada teste
        database.getDb().run('DELETE FROM clientes', done);
    });

    describe('POST /api/clientes', function() {
        it('deve criar um novo cliente com dados válidos', function(done) {
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .expect(201)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('id');
                    expect(res.body.nome).to.equal(clienteData.nome);
                    expect(res.body.email).to.equal(clienteData.email);
                    expect(res.body.telefone).to.equal(clienteData.telefone);
                    done();
                });
        });

        it('deve retornar erro 400 quando nome está vazio', function(done) {
            const clienteData = {
                nome: '',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .expect(400)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('errors');
                    expect(res.body.errors).to.include('Nome é obrigatório');
                    done();
                });
        });

        it('deve retornar erro 400 quando email está vazio', function(done) {
            const clienteData = {
                nome: 'João Silva',
                email: '',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .expect(400)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('errors');
                    expect(res.body.errors).to.include('Email é obrigatório');
                    done();
                });
        });

        it('deve retornar erro 400 quando email tem formato inválido', function(done) {
            const clienteData = {
                nome: 'João Silva',
                email: 'email-invalido',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .expect(400)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('errors');
                    expect(res.body.errors).to.include('Email deve ter um formato válido');
                    done();
                });
        });
    });

    describe('GET /api/clientes', function() {
        it('deve retornar lista vazia quando não há clientes', function(done) {
            request(app)
                .get('/api/clientes')
                .expect(200)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.be.an('array').that.is.empty;
                    done();
                });
        });

        it('deve retornar lista de clientes', function(done) {
            // Primeiro criar um cliente
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .end(function(err, res) {
                    if (err) return done(err);

                    // Agora buscar a lista
                    request(app)
                        .get('/api/clientes')
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.be.an('array').with.length(1);
                            expect(res.body[0]).to.have.property('nome');
                            expect(res.body[0]).to.have.property('email');
                            done();
                        });
                });
        });
    });

    describe('GET /api/clientes/:id', function() {
        it('deve retornar cliente específico', function(done) {
            // Primeiro criar um cliente
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const clienteId = res.body.id;

                    // Agora buscar o cliente específico
                    request(app)
                        .get(`/api/clientes/${clienteId}`)
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.have.property('id', clienteId);
                            expect(res.body.nome).to.equal(clienteData.nome);
                            expect(res.body.email).to.equal(clienteData.email);
                            done();
                        });
                });
        });

        it('deve retornar erro 404 quando cliente não existe', function(done) {
            request(app)
                .get('/api/clientes/999')
                .expect(404)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('error');
                    expect(res.body.error).to.equal('Cliente não encontrado');
                    done();
                });
        });
    });

    describe('PUT /api/clientes/:id', function() {
        it('deve atualizar cliente existente', function(done) {
            // Primeiro criar um cliente
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const clienteId = res.body.id;
                    const dadosAtualizados = {
                        nome: 'João Santos',
                        email: 'joao.santos@email.com',
                        telefone: '11888888888'
                    };

                    // Agora atualizar o cliente
                    request(app)
                        .put(`/api/clientes/${clienteId}`)
                        .send(dadosAtualizados)
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body.nome).to.equal(dadosAtualizados.nome);
                            expect(res.body.email).to.equal(dadosAtualizados.email);
                            expect(res.body.telefone).to.equal(dadosAtualizados.telefone);
                            done();
                        });
                });
        });

        it('deve retornar erro 404 quando cliente não existe', function(done) {
            const dadosAtualizados = {
                nome: 'João Santos',
                email: 'joao.santos@email.com',
                telefone: '11888888888'
            };

            request(app)
                .put('/api/clientes/999')
                .send(dadosAtualizados)
                .expect(404)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('error');
                    expect(res.body.error).to.equal('Cliente não encontrado');
                    done();
                });
        });

        it('deve retornar erro 400 quando dados são inválidos', function(done) {
            // Primeiro criar um cliente
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const clienteId = res.body.id;
                    const dadosInvalidos = {
                        nome: '',
                        email: 'email-invalido',
                        telefone: '11888888888'
                    };

                    // Tentar atualizar com dados inválidos
                    request(app)
                        .put(`/api/clientes/${clienteId}`)
                        .send(dadosInvalidos)
                        .expect(400)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.have.property('errors');
                            expect(res.body.errors).to.include('Nome é obrigatório');
                            done();
                        });
                });
        });
    });

    describe('DELETE /api/clientes/:id', function() {
        it('deve deletar cliente existente', function(done) {
            // Primeiro criar um cliente
            const clienteData = {
                nome: 'João Silva',
                email: 'joao@email.com',
                telefone: '11999999999'
            };

            request(app)
                .post('/api/clientes')
                .send(clienteData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const clienteId = res.body.id;

                    // Agora deletar o cliente
                    request(app)
                        .delete(`/api/clientes/${clienteId}`)
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.have.property('message');
                            expect(res.body.message).to.equal('Cliente deletado com sucesso');

                            // Verificar se foi realmente deletado
                            request(app)
                                .get(`/api/clientes/${clienteId}`)
                                .expect(404, done);
                        });
                });
        });

        it('deve retornar erro 404 quando cliente não existe', function(done) {
            request(app)
                .delete('/api/clientes/999')
                .expect(404)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('error');
                    expect(res.body.error).to.equal('Cliente não encontrado');
                    done();
                });
        });
    });
});

