const request = require('supertest');
const { expect } = require('chai');
const app = require('../../app');
const database = require('../../src/database/database');

describe('Venda API - Testes de Integração', function() {
    // Configurar timeout para operações de banco
    this.timeout(10000);

    let clienteId;

    before(function(done) {
        // Inicializar banco de dados de teste
        database.init();
        setTimeout(done, 2000); // Aguardar inicialização
    });

    beforeEach(function(done) {
        // Limpar tabelas antes de cada teste
        database.getDb().run('DELETE FROM vendas', () => {
            database.getDb().run('DELETE FROM clientes', () => {
                // Criar um cliente para usar nos testes
                const clienteData = {
                    nome: 'João Silva',
                    email: 'joao@email.com',
                    telefone: '11999999999'
                };

                request(app)
                    .post('/api/clientes')
                    .send(clienteData)
                    .end(function(err, res) {
                        if (err) return done(err);
                        clienteId = res.body.id;
                        done();
                    });
            });
        });
    });

    describe('POST /api/vendas', function() {
        it('deve criar uma nova venda com dados válidos', function(done) {
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .expect(201)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('id');
                    expect(res.body.cliente_id).to.equal(vendaData.cliente_id);
                    expect(res.body.data_venda).to.equal(vendaData.data_venda);
                    expect(res.body.valor_total).to.equal(vendaData.valor_total);
                    expect(res.body.descricao).to.equal(vendaData.descricao);
                    done();
                });
        });

        it('deve retornar erro 400 quando cliente_id está vazio', function(done) {
            const vendaData = {
                cliente_id: '',
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .expect(400)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('errors');
                    expect(res.body.errors).to.include('Cliente é obrigatório');
                    done();
                });
        });

        it('deve retornar erro 400 quando data_venda está vazia', function(done) {
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .expect(400)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('errors');
                    expect(res.body.errors).to.include('Data da venda é obrigatória');
                    done();
                });
        });

        it('deve retornar erro 400 quando valor_total é inválido', function(done) {
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 0,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .expect(400)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('errors');
                    expect(res.body.errors).to.include('Valor total deve ser um número positivo');
                    done();
                });
        });
    });

    describe('GET /api/vendas', function() {
        it('deve retornar lista vazia quando não há vendas', function(done) {
            request(app)
                .get('/api/vendas')
                .expect(200)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.be.an('array').that.is.empty;
                    done();
                });
        });

        it('deve retornar lista de vendas com informações do cliente', function(done) {
            // Primeiro criar uma venda
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .end(function(err, res) {
                    if (err) return done(err);

                    // Agora buscar a lista
                    request(app)
                        .get('/api/vendas')
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.be.an('array').with.length(1);
                            expect(res.body[0]).to.have.property('cliente_nome');
                            expect(res.body[0]).to.have.property('cliente_email');
                            expect(res.body[0]).to.have.property('valor_total');
                            done();
                        });
                });
        });
    });

    describe('GET /api/vendas/:id', function() {
        it('deve retornar venda específica com informações do cliente', function(done) {
            // Primeiro criar uma venda
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const vendaId = res.body.id;

                    // Agora buscar a venda específica
                    request(app)
                        .get(`/api/vendas/${vendaId}`)
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.have.property('id', vendaId);
                            expect(res.body.valor_total).to.equal(vendaData.valor_total);
                            expect(res.body).to.have.property('cliente_nome');
                            expect(res.body).to.have.property('cliente_email');
                            done();
                        });
                });
        });

        it('deve retornar erro 404 quando venda não existe', function(done) {
            request(app)
                .get('/api/vendas/999')
                .expect(404)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('error');
                    expect(res.body.error).to.equal('Venda não encontrada');
                    done();
                });
        });
    });

    describe('PUT /api/vendas/:id', function() {
        it('deve atualizar venda existente', function(done) {
            // Primeiro criar uma venda
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const vendaId = res.body.id;
                    const dadosAtualizados = {
                        cliente_id: clienteId,
                        data_venda: '2025-07-21',
                        valor_total: 200.00,
                        descricao: 'Venda atualizada'
                    };

                    // Agora atualizar a venda
                    request(app)
                        .put(`/api/vendas/${vendaId}`)
                        .send(dadosAtualizados)
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body.data_venda).to.equal(dadosAtualizados.data_venda);
                            expect(res.body.valor_total).to.equal(dadosAtualizados.valor_total);
                            expect(res.body.descricao).to.equal(dadosAtualizados.descricao);
                            done();
                        });
                });
        });

        it('deve retornar erro 404 quando venda não existe', function(done) {
            const dadosAtualizados = {
                cliente_id: clienteId,
                data_venda: '2025-07-21',
                valor_total: 200.00,
                descricao: 'Venda atualizada'
            };

            request(app)
                .put('/api/vendas/999')
                .send(dadosAtualizados)
                .expect(404)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('error');
                    expect(res.body.error).to.equal('Venda não encontrada');
                    done();
                });
        });

        it('deve retornar erro 400 quando dados são inválidos', function(done) {
            // Primeiro criar uma venda
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const vendaId = res.body.id;
                    const dadosInvalidos = {
                        cliente_id: '',
                        data_venda: '',
                        valor_total: 0,
                        descricao: 'Venda atualizada'
                    };

                    // Tentar atualizar com dados inválidos
                    request(app)
                        .put(`/api/vendas/${vendaId}`)
                        .send(dadosInvalidos)
                        .expect(400)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.have.property('errors');
                            expect(res.body.errors).to.include('Cliente é obrigatório');
                            done();
                        });
                });
        });
    });

    describe('DELETE /api/vendas/:id', function() {
        it('deve deletar venda existente', function(done) {
            // Primeiro criar uma venda
            const vendaData = {
                cliente_id: clienteId,
                data_venda: '2025-07-20',
                valor_total: 150.75,
                descricao: 'Venda de teste'
            };

            request(app)
                .post('/api/vendas')
                .send(vendaData)
                .end(function(err, res) {
                    if (err) return done(err);

                    const vendaId = res.body.id;

                    // Agora deletar a venda
                    request(app)
                        .delete(`/api/vendas/${vendaId}`)
                        .expect(200)
                        .end(function(err, res) {
                            if (err) return done(err);
                            
                            expect(res.body).to.have.property('message');
                            expect(res.body.message).to.equal('Venda deletada com sucesso');

                            // Verificar se foi realmente deletada
                            request(app)
                                .get(`/api/vendas/${vendaId}`)
                                .expect(404, done);
                        });
                });
        });

        it('deve retornar erro 404 quando venda não existe', function(done) {
            request(app)
                .delete('/api/vendas/999')
                .expect(404)
                .end(function(err, res) {
                    if (err) return done(err);
                    
                    expect(res.body).to.have.property('error');
                    expect(res.body.error).to.equal('Venda não encontrada');
                    done();
                });
        });
    });
});

