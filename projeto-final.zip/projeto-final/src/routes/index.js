const express = require('express');
const router = express.Router();

// Rota principal - Dashboard
router.get('/', (req, res) => {
    res.render('index', { 
        title: 'Sistema de Controle de Vendas e Clientes' 
    });
});

module.exports = router;

