const express = require('express');
const router = express.Router();
const ClienteController = require('../controllers/clienteController');
const VendaController = require('../controllers/vendaController');

// Rotas da API para Clientes
router.get('/clientes', ClienteController.apiIndex);
router.get('/clientes/:id', ClienteController.apiShow);
router.post('/clientes', ClienteController.apiCreate);
router.put('/clientes/:id', ClienteController.apiUpdate);
router.delete('/clientes/:id', ClienteController.apiDelete);

// Rotas da API para Vendas
router.get('/vendas', VendaController.apiIndex);
router.get('/vendas/:id', VendaController.apiShow);
router.post('/vendas', VendaController.apiCreate);
router.put('/vendas/:id', VendaController.apiUpdate);
router.delete('/vendas/:id', VendaController.apiDelete);

module.exports = router;

