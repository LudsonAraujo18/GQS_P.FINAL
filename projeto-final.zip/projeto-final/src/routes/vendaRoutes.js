const express = require('express');
const router = express.Router();
const VendaController = require('../controllers/vendaController');

// Rotas para views (HTML)
router.get('/', VendaController.index);
router.get('/novo', VendaController.novo);
router.post('/', VendaController.create);
router.get('/:id', VendaController.show);
router.get('/:id/editar', VendaController.editar);
router.put('/:id', VendaController.update);
router.delete('/:id', VendaController.delete);

module.exports = router;

