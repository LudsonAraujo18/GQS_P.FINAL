const express = require('express');
const router = express.Router();
const ClienteController = require('../controllers/clienteController');

// Rotas para views (HTML)
router.get('/', ClienteController.index);
router.get('/novo', ClienteController.novo);
router.post('/', ClienteController.create);
router.get('/:id', ClienteController.show);
router.get('/:id/editar', ClienteController.editar);
router.put('/:id', ClienteController.update);
router.delete('/:id', ClienteController.delete);

module.exports = router;

