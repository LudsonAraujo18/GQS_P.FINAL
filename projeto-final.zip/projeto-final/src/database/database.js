const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'vendas_clientes.db');

class Database {
    constructor() {
        this.db = null;
    }

    init() {
        this.db = new sqlite3.Database(dbPath, (err) => {
            if (err) {
                console.error('Erro ao conectar com o banco de dados:', err.message);
            } else {
                console.log('Conectado ao banco de dados SQLite.');
                this.createTables();
            }
        });
    }

    createTables() {
        // Criar tabela de clientes
        const createClientesTable = `
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                telefone TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `;

        // Criar tabela de vendas
        const createVendasTable = `
            CREATE TABLE IF NOT EXISTS vendas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_id INTEGER NOT NULL,
                data_venda TEXT NOT NULL,
                valor_total REAL NOT NULL,
                descricao TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (cliente_id) REFERENCES clientes (id) ON DELETE CASCADE
            )
        `;

        this.db.run(createClientesTable, (err) => {
            if (err) {
                console.error('Erro ao criar tabela clientes:', err.message);
            } else {
                console.log('Tabela clientes criada/verificada com sucesso.');
            }
        });

        this.db.run(createVendasTable, (err) => {
            if (err) {
                console.error('Erro ao criar tabela vendas:', err.message);
            } else {
                console.log('Tabela vendas criada/verificada com sucesso.');
            }
        });
    }

    getDb() {
        return this.db;
    }

    close() {
        if (this.db) {
            this.db.close((err) => {
                if (err) {
                    console.error('Erro ao fechar o banco de dados:', err.message);
                } else {
                    console.log('Conexão com o banco de dados fechada.');
                }
            });
        }
    }
}

module.exports = new Database();

