// Funções utilitárias para o sistema

// Formatação de telefone
function formatarTelefone(input) {
    let valor = input.value.replace(/\D/g, '');
    
    if (valor.length <= 10) {
        valor = valor.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    } else {
        valor = valor.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    
    input.value = valor;
}

// Formatação de valor monetário
function formatarValor(input) {
    let valor = input.value.replace(/\D/g, '');
    valor = (valor / 100).toFixed(2);
    input.value = valor;
}

// Validação de formulários
function validarFormularioCliente(form) {
    const nome = form.querySelector('#nome').value.trim();
    const email = form.querySelector('#email').value.trim();
    
    if (!nome) {
        alert('Nome é obrigatório');
        return false;
    }
    
    if (!email) {
        alert('Email é obrigatório');
        return false;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Email deve ter um formato válido');
        return false;
    }
    
    return true;
}

function validarFormularioVenda(form) {
    const cliente_id = form.querySelector('#cliente_id').value;
    const data_venda = form.querySelector('#data_venda').value;
    const valor_total = form.querySelector('#valor_total').value;
    
    if (!cliente_id) {
        alert('Cliente é obrigatório');
        return false;
    }
    
    if (!data_venda) {
        alert('Data da venda é obrigatória');
        return false;
    }
    
    if (!valor_total || parseFloat(valor_total) <= 0) {
        alert('Valor total deve ser um número positivo');
        return false;
    }
    
    return true;
}

// Inicialização quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    // Formatação automática de telefone
    const telefoneInputs = document.querySelectorAll('input[type="tel"]');
    telefoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            formatarTelefone(this);
        });
    });
    
    // Validação de formulários
    const clienteForm = document.getElementById('clienteForm');
    if (clienteForm) {
        clienteForm.addEventListener('submit', function(e) {
            if (!validarFormularioCliente(this)) {
                e.preventDefault();
            }
        });
    }
    
    const vendaForm = document.getElementById('vendaForm');
    if (vendaForm) {
        vendaForm.addEventListener('submit', function(e) {
            if (!validarFormularioVenda(this)) {
                e.preventDefault();
            }
        });
    }
    
    // Auto-hide alerts após 5 segundos
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 5000);
    });
    
    // Confirmação de exclusão
    const deleteButtons = document.querySelectorAll('button[type="submit"]');
    deleteButtons.forEach(button => {
        if (button.textContent.includes('Deletar')) {
            button.addEventListener('click', function(e) {
                if (!confirm('Tem certeza que deseja deletar este item? Esta ação não pode ser desfeita.')) {
                    e.preventDefault();
                }
            });
        }
    });
});

