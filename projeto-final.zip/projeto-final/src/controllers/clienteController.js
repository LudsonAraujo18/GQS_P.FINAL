const Cliente = require('../models/Cliente');

class ClienteController {
    // GET /clientes - Listar todos os clientes
    static async index(req, res) {
        try {
            const clientes = await Cliente.findAll();
            res.render('clientes/lista', { 
                title: 'Lista de Clientes',
                clientes: clientes 
            });
        } catch (error) {
            console.error('Erro ao buscar clientes:', error);
            res.status(500).render('partials/error', { 
                title: 'Erro',
                error: 'Erro ao carregar lista de clientes' 
            });
        }
    }

    // GET /clientes/novo - Exibir formulário de cadastro
    static async novo(req, res) {
        res.render('clientes/novo', { 
            title: 'Novo Cliente',
            errors: [],
            cliente: {}
        });
    }

    // POST /clientes - Criar novo cliente
    static async create(req, res) {
        try {
            const clienteData = {
                nome: req.body.nome,
                email: req.body.email,
                telefone: req.body.telefone
            };

            const errors = Cliente.validate(clienteData);
            if (errors.length > 0) {
                return res.status(400).render('clientes/novo', {
                    title: 'Novo Cliente',
                    errors: errors,
                    cliente: clienteData
                });
            }

            const novoCliente = await Cliente.create(clienteData);
            res.redirect('/clientes?success=Cliente cadastrado com sucesso');
        } catch (error) {
            console.error('Erro ao criar cliente:', error);
            
            let errorMessage = 'Erro ao cadastrar cliente';
            if (error.message.includes('UNIQUE constraint failed')) {
                errorMessage = 'Este email já está cadastrado';
            }
            
            res.status(500).render('clientes/novo', {
                title: 'Novo Cliente',
                errors: [errorMessage],
                cliente: req.body
            });
        }
    }

    // GET /clientes/:id - Exibir cliente específico
    static async show(req, res) {
        try {
            const cliente = await Cliente.findById(req.params.id);
            if (!cliente) {
                return res.status(404).render('partials/404', { 
                    title: 'Cliente não encontrado' 
                });
            }
            
            res.render('clientes/detalhes', { 
                title: 'Detalhes do Cliente',
                cliente: cliente 
            });
        } catch (error) {
            console.error('Erro ao buscar cliente:', error);
            res.status(500).render('partials/error', { 
                title: 'Erro',
                error: 'Erro ao carregar cliente' 
            });
        }
    }

    // GET /clientes/:id/editar - Exibir formulário de edição
    static async editar(req, res) {
        try {
            const cliente = await Cliente.findById(req.params.id);
            if (!cliente) {
                return res.status(404).render('partials/404', { 
                    title: 'Cliente não encontrado' 
                });
            }
            
            res.render('clientes/editar', { 
                title: 'Editar Cliente',
                cliente: cliente,
                errors: []
            });
        } catch (error) {
            console.error('Erro ao buscar cliente:', error);
            res.status(500).render('partials/error', { 
                title: 'Erro',
                error: 'Erro ao carregar cliente' 
            });
        }
    }

    // PUT /clientes/:id - Atualizar cliente
    static async update(req, res) {
        try {
            const clienteData = {
                nome: req.body.nome,
                email: req.body.email,
                telefone: req.body.telefone
            };

            const errors = Cliente.validate(clienteData);
            if (errors.length > 0) {
                return res.status(400).render('clientes/editar', {
                    title: 'Editar Cliente',
                    errors: errors,
                    cliente: { id: req.params.id, ...clienteData }
                });
            }

            await Cliente.update(req.params.id, clienteData);
            res.redirect('/clientes?success=Cliente atualizado com sucesso');
        } catch (error) {
            console.error('Erro ao atualizar cliente:', error);
            
            let errorMessage = 'Erro ao atualizar cliente';
            if (error.message.includes('UNIQUE constraint failed')) {
                errorMessage = 'Este email já está cadastrado';
            } else if (error.message === 'Cliente não encontrado') {
                return res.status(404).render('partials/404', { 
                    title: 'Cliente não encontrado' 
                });
            }
            
            res.status(500).render('clientes/editar', {
                title: 'Editar Cliente',
                errors: [errorMessage],
                cliente: { id: req.params.id, ...req.body }
            });
        }
    }

    // DELETE /clientes/:id - Deletar cliente
    static async delete(req, res) {
        try {
            await Cliente.delete(req.params.id);
            res.redirect('/clientes?success=Cliente deletado com sucesso');
        } catch (error) {
            console.error('Erro ao deletar cliente:', error);
            
            if (error.message === 'Cliente não encontrado') {
                return res.status(404).render('partials/404', { 
                    title: 'Cliente não encontrado' 
                });
            }
            
            res.redirect('/clientes?error=Erro ao deletar cliente');
        }
    }

    // API Routes para testes
    // GET /api/clientes - Listar todos os clientes (JSON)
    static async apiIndex(req, res) {
        try {
            const clientes = await Cliente.findAll();
            res.json(clientes);
        } catch (error) {
            console.error('Erro ao buscar clientes:', error);
            res.status(500).json({ error: 'Erro ao carregar clientes' });
        }
    }

    // GET /api/clientes/:id - Buscar cliente por ID (JSON)
    static async apiShow(req, res) {
        try {
            const cliente = await Cliente.findById(req.params.id);
            if (!cliente) {
                return res.status(404).json({ error: 'Cliente não encontrado' });
            }
            res.json(cliente);
        } catch (error) {
            console.error('Erro ao buscar cliente:', error);
            res.status(500).json({ error: 'Erro ao carregar cliente' });
        }
    }

    // POST /api/clientes - Criar novo cliente (JSON)
    static async apiCreate(req, res) {
        try {
            const clienteData = {
                nome: req.body.nome,
                email: req.body.email,
                telefone: req.body.telefone
            };

            const errors = Cliente.validate(clienteData);
            if (errors.length > 0) {
                return res.status(400).json({ errors: errors });
            }

            const novoCliente = await Cliente.create(clienteData);
            res.status(201).json(novoCliente);
        } catch (error) {
            console.error('Erro ao criar cliente:', error);
            
            if (error.message.includes('UNIQUE constraint failed')) {
                return res.status(400).json({ error: 'Este email já está cadastrado' });
            }
            
            res.status(500).json({ error: 'Erro ao cadastrar cliente' });
        }
    }

    // PUT /api/clientes/:id - Atualizar cliente (JSON)
    static async apiUpdate(req, res) {
        try {
            const clienteData = {
                nome: req.body.nome,
                email: req.body.email,
                telefone: req.body.telefone
            };

            const errors = Cliente.validate(clienteData);
            if (errors.length > 0) {
                return res.status(400).json({ errors: errors });
            }

            const clienteAtualizado = await Cliente.update(req.params.id, clienteData);
            res.json(clienteAtualizado);
        } catch (error) {
            console.error('Erro ao atualizar cliente:', error);
            
            if (error.message === 'Cliente não encontrado') {
                return res.status(404).json({ error: 'Cliente não encontrado' });
            }
            
            if (error.message.includes('UNIQUE constraint failed')) {
                return res.status(400).json({ error: 'Este email já está cadastrado' });
            }
            
            res.status(500).json({ error: 'Erro ao atualizar cliente' });
        }
    }

    // DELETE /api/clientes/:id - Deletar cliente (JSON)
    static async apiDelete(req, res) {
        try {
            await Cliente.delete(req.params.id);
            res.json({ message: 'Cliente deletado com sucesso' });
        } catch (error) {
            console.error('Erro ao deletar cliente:', error);
            
            if (error.message === 'Cliente não encontrado') {
                return res.status(404).json({ error: 'Cliente não encontrado' });
            }
            
            res.status(500).json({ error: 'Erro ao deletar cliente' });
        }
    }
}

module.exports = ClienteController;

