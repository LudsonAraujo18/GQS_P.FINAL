const Venda = require('../models/Venda');
const Cliente = require('../models/Cliente');

class VendaController {
    // GET /vendas - Listar todas as vendas
    static async index(req, res) {
        try {
            const vendas = await Venda.findAll();
            res.render('vendas/lista', { 
                title: 'Lista de Vendas',
                vendas: vendas 
            });
        } catch (error) {
            console.error('Erro ao buscar vendas:', error);
            res.status(500).render('partials/error', { 
                title: 'Erro',
                error: 'Erro ao carregar lista de vendas' 
            });
        }
    }

    // GET /vendas/novo - Exibir formulário de cadastro
    static async novo(req, res) {
        try {
            const clientes = await Cliente.findAll();
            res.render('vendas/novo', { 
                title: 'Nova Venda',
                errors: [],
                venda: {},
                clientes: clientes
            });
        } catch (error) {
            console.error('Erro ao buscar clientes:', error);
            res.status(500).render('partials/error', { 
                title: 'Erro',
                error: 'Erro ao carregar formulário de venda' 
            });
        }
    }

    // POST /vendas - Criar nova venda
    static async create(req, res) {
        try {
            const vendaData = {
                cliente_id: req.body.cliente_id,
                data_venda: req.body.data_venda,
                valor_total: req.body.valor_total,
                descricao: req.body.descricao
            };

            const errors = Venda.validate(vendaData);
            if (errors.length > 0) {
                const clientes = await Cliente.findAll();
                return res.status(400).render('vendas/novo', {
                    title: 'Nova Venda',
                    errors: errors,
                    venda: vendaData,
                    clientes: clientes
                });
            }

            const novaVenda = await Venda.create(vendaData);
            res.redirect('/vendas?success=Venda cadastrada com sucesso');
        } catch (error) {
            console.error('Erro ao criar venda:', error);
            
            try {
                const clientes = await Cliente.findAll();
                res.status(500).render('vendas/novo', {
                    title: 'Nova Venda',
                    errors: ['Erro ao cadastrar venda'],
                    venda: req.body,
                    clientes: clientes
                });
            } catch (clienteError) {
                res.status(500).render('partials/error', { 
                    title: 'Erro',
                    error: 'Erro ao cadastrar venda' 
                });
            }
        }
    }

    // GET /vendas/:id - Exibir venda específica
    static async show(req, res) {
        try {
            const venda = await Venda.findById(req.params.id);
            if (!venda) {
                return res.status(404).render('partials/404', { 
                    title: 'Venda não encontrada' 
                });
            }
            
            res.render('vendas/detalhes', { 
                title: 'Detalhes da Venda',
                venda: venda 
            });
        } catch (error) {
            console.error('Erro ao buscar venda:', error);
            res.status(500).render('partials/error', { 
                title: 'Erro',
                error: 'Erro ao carregar venda' 
            });
        }
    }

    // GET /vendas/:id/editar - Exibir formulário de edição
    static async editar(req, res) {
        try {
            const venda = await Venda.findById(req.params.id);
            if (!venda) {
                return res.status(404).render('partials/404', { 
                    title: 'Venda não encontrada' 
                });
            }
            
            const clientes = await Cliente.findAll();
            res.render('vendas/editar', { 
                title: 'Editar Venda',
                venda: venda,
                clientes: clientes,
                errors: []
            });
        } catch (error) {
            console.error('Erro ao buscar venda:', error);
            res.status(500).render('partials/error', { 
                title: 'Erro',
                error: 'Erro ao carregar venda' 
            });
        }
    }

    // PUT /vendas/:id - Atualizar venda
    static async update(req, res) {
        try {
            const vendaData = {
                cliente_id: req.body.cliente_id,
                data_venda: req.body.data_venda,
                valor_total: req.body.valor_total,
                descricao: req.body.descricao
            };

            const errors = Venda.validate(vendaData);
            if (errors.length > 0) {
                const clientes = await Cliente.findAll();
                return res.status(400).render('vendas/editar', {
                    title: 'Editar Venda',
                    errors: errors,
                    venda: { id: req.params.id, ...vendaData },
                    clientes: clientes
                });
            }

            await Venda.update(req.params.id, vendaData);
            res.redirect('/vendas?success=Venda atualizada com sucesso');
        } catch (error) {
            console.error('Erro ao atualizar venda:', error);
            
            if (error.message === 'Venda não encontrada') {
                return res.status(404).render('partials/404', { 
                    title: 'Venda não encontrada' 
                });
            }
            
            try {
                const clientes = await Cliente.findAll();
                res.status(500).render('vendas/editar', {
                    title: 'Editar Venda',
                    errors: ['Erro ao atualizar venda'],
                    venda: { id: req.params.id, ...req.body },
                    clientes: clientes
                });
            } catch (clienteError) {
                res.status(500).render('partials/error', { 
                    title: 'Erro',
                    error: 'Erro ao atualizar venda' 
                });
            }
        }
    }

    // DELETE /vendas/:id - Deletar venda
    static async delete(req, res) {
        try {
            await Venda.delete(req.params.id);
            res.redirect('/vendas?success=Venda deletada com sucesso');
        } catch (error) {
            console.error('Erro ao deletar venda:', error);
            
            if (error.message === 'Venda não encontrada') {
                return res.status(404).render('partials/404', { 
                    title: 'Venda não encontrada' 
                });
            }
            
            res.redirect('/vendas?error=Erro ao deletar venda');
        }
    }

    // API Routes para testes
    // GET /api/vendas - Listar todas as vendas (JSON)
    static async apiIndex(req, res) {
        try {
            const vendas = await Venda.findAll();
            res.json(vendas);
        } catch (error) {
            console.error('Erro ao buscar vendas:', error);
            res.status(500).json({ error: 'Erro ao carregar vendas' });
        }
    }

    // GET /api/vendas/:id - Buscar venda por ID (JSON)
    static async apiShow(req, res) {
        try {
            const venda = await Venda.findById(req.params.id);
            if (!venda) {
                return res.status(404).json({ error: 'Venda não encontrada' });
            }
            res.json(venda);
        } catch (error) {
            console.error('Erro ao buscar venda:', error);
            res.status(500).json({ error: 'Erro ao carregar venda' });
        }
    }

    // POST /api/vendas - Criar nova venda (JSON)
    static async apiCreate(req, res) {
        try {
            const vendaData = {
                cliente_id: req.body.cliente_id,
                data_venda: req.body.data_venda,
                valor_total: req.body.valor_total,
                descricao: req.body.descricao
            };

            const errors = Venda.validate(vendaData);
            if (errors.length > 0) {
                return res.status(400).json({ errors: errors });
            }

            const novaVenda = await Venda.create(vendaData);
            res.status(201).json(novaVenda);
        } catch (error) {
            console.error('Erro ao criar venda:', error);
            res.status(500).json({ error: 'Erro ao cadastrar venda' });
        }
    }

    // PUT /api/vendas/:id - Atualizar venda (JSON)
    static async apiUpdate(req, res) {
        try {
            const vendaData = {
                cliente_id: req.body.cliente_id,
                data_venda: req.body.data_venda,
                valor_total: req.body.valor_total,
                descricao: req.body.descricao
            };

            const errors = Venda.validate(vendaData);
            if (errors.length > 0) {
                return res.status(400).json({ errors: errors });
            }

            const vendaAtualizada = await Venda.update(req.params.id, vendaData);
            res.json(vendaAtualizada);
        } catch (error) {
            console.error('Erro ao atualizar venda:', error);
            
            if (error.message === 'Venda não encontrada') {
                return res.status(404).json({ error: 'Venda não encontrada' });
            }
            
            res.status(500).json({ error: 'Erro ao atualizar venda' });
        }
    }

    // DELETE /api/vendas/:id - Deletar venda (JSON)
    static async apiDelete(req, res) {
        try {
            await Venda.delete(req.params.id);
            res.json({ message: 'Venda deletada com sucesso' });
        } catch (error) {
            console.error('Erro ao deletar venda:', error);
            
            if (error.message === 'Venda não encontrada') {
                return res.status(404).json({ error: 'Venda não encontrada' });
            }
            
            res.status(500).json({ error: 'Erro ao deletar venda' });
        }
    }
}

module.exports = VendaController;

