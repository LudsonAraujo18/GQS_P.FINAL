const database = require('../database/database');

class Venda {
    constructor(cliente_id, data_venda, valor_total, descricao) {
        this.cliente_id = cliente_id;
        this.data_venda = data_venda;
        this.valor_total = valor_total;
        this.descricao = descricao;
    }

    // Criar uma nova venda
    static create(vendaData) {
        return new Promise((resolve, reject) => {
            const { cliente_id, data_venda, valor_total, descricao } = vendaData;
            const sql = `INSERT INTO vendas (cliente_id, data_venda, valor_total, descricao) VALUES (?, ?, ?, ?)`;
            
            database.getDb().run(sql, [cliente_id, data_venda, valor_total, descricao], function(err) {
                if (err) {
                    reject(err);
                } else {
                    resolve({ id: this.lastID, cliente_id, data_venda, valor_total, descricao });
                }
            });
        });
    }

    // Buscar todas as vendas com informações do cliente
    static findAll() {
        return new Promise((resolve, reject) => {
            const sql = `
                SELECT v.*, c.nome as cliente_nome, c.email as cliente_email 
                FROM vendas v 
                JOIN clientes c ON v.cliente_id = c.id 
                ORDER BY v.data_venda DESC
            `;
            
            database.getDb().all(sql, [], (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }

    // Buscar venda por ID
    static findById(id) {
        return new Promise((resolve, reject) => {
            const sql = `
                SELECT v.*, c.nome as cliente_nome, c.email as cliente_email 
                FROM vendas v 
                JOIN clientes c ON v.cliente_id = c.id 
                WHERE v.id = ?
            `;
            
            database.getDb().get(sql, [id], (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }

    // Atualizar venda
    static update(id, vendaData) {
        return new Promise((resolve, reject) => {
            const { cliente_id, data_venda, valor_total, descricao } = vendaData;
            const sql = `UPDATE vendas SET cliente_id = ?, data_venda = ?, valor_total = ?, descricao = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
            
            database.getDb().run(sql, [cliente_id, data_venda, valor_total, descricao, id], function(err) {
                if (err) {
                    reject(err);
                } else {
                    if (this.changes === 0) {
                        reject(new Error('Venda não encontrada'));
                    } else {
                        resolve({ id, cliente_id, data_venda, valor_total, descricao });
                    }
                }
            });
        });
    }

    // Deletar venda
    static delete(id) {
        return new Promise((resolve, reject) => {
            const sql = `DELETE FROM vendas WHERE id = ?`;
            
            database.getDb().run(sql, [id], function(err) {
                if (err) {
                    reject(err);
                } else {
                    if (this.changes === 0) {
                        reject(new Error('Venda não encontrada'));
                    } else {
                        resolve({ message: 'Venda deletada com sucesso' });
                    }
                }
            });
        });
    }

    // Validar dados da venda
    static validate(vendaData) {
        const errors = [];
        
        if (!vendaData.cliente_id || isNaN(vendaData.cliente_id)) {
            errors.push('Cliente é obrigatório');
        }
        
        if (!vendaData.data_venda || vendaData.data_venda.trim().length === 0) {
            errors.push('Data da venda é obrigatória');
        }
        
        if (!vendaData.valor_total || isNaN(vendaData.valor_total) || parseFloat(vendaData.valor_total) <= 0) {
            errors.push('Valor total deve ser um número positivo');
        }
        
        return errors;
    }

    // Buscar vendas por cliente
    static findByClienteId(cliente_id) {
        return new Promise((resolve, reject) => {
            const sql = `
                SELECT v.*, c.nome as cliente_nome, c.email as cliente_email 
                FROM vendas v 
                JOIN clientes c ON v.cliente_id = c.id 
                WHERE v.cliente_id = ?
                ORDER BY v.data_venda DESC
            `;
            
            database.getDb().all(sql, [cliente_id], (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }
}

module.exports = Venda;

