const database = require('../database/database');

class Cliente {
    constructor(nome, email, telefone) {
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
    }

    // Criar um novo cliente
    static create(clienteData) {
        return new Promise((resolve, reject) => {
            const { nome, email, telefone } = clienteData;
            const sql = `INSERT INTO clientes (nome, email, telefone) VALUES (?, ?, ?)`;
            
            database.getDb().run(sql, [nome, email, telefone], function(err) {
                if (err) {
                    reject(err);
                } else {
                    resolve({ id: this.lastID, nome, email, telefone });
                }
            });
        });
    }

    // Buscar todos os clientes
    static findAll() {
        return new Promise((resolve, reject) => {
            const sql = `SELECT * FROM clientes ORDER BY nome`;
            
            database.getDb().all(sql, [], (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }

    // Buscar cliente por ID
    static findById(id) {
        return new Promise((resolve, reject) => {
            const sql = `SELECT * FROM clientes WHERE id = ?`;
            
            database.getDb().get(sql, [id], (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }

    // Atualizar cliente
    static update(id, clienteData) {
        return new Promise((resolve, reject) => {
            const { nome, email, telefone } = clienteData;
            const sql = `UPDATE clientes SET nome = ?, email = ?, telefone = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
            
            database.getDb().run(sql, [nome, email, telefone, id], function(err) {
                if (err) {
                    reject(err);
                } else {
                    if (this.changes === 0) {
                        reject(new Error('Cliente não encontrado'));
                    } else {
                        resolve({ id, nome, email, telefone });
                    }
                }
            });
        });
    }

    // Deletar cliente
    static delete(id) {
        return new Promise((resolve, reject) => {
            const sql = `DELETE FROM clientes WHERE id = ?`;
            
            database.getDb().run(sql, [id], function(err) {
                if (err) {
                    reject(err);
                } else {
                    if (this.changes === 0) {
                        reject(new Error('Cliente não encontrado'));
                    } else {
                        resolve({ message: 'Cliente deletado com sucesso' });
                    }
                }
            });
        });
    }

    // Validar dados do cliente
    static validate(clienteData) {
        const errors = [];
        
        if (!clienteData.nome || clienteData.nome.trim().length === 0) {
            errors.push('Nome é obrigatório');
        }
        
        if (!clienteData.email || clienteData.email.trim().length === 0) {
            errors.push('Email é obrigatório');
        } else {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(clienteData.email)) {
                errors.push('Email deve ter um formato válido');
            }
        }
        
        return errors;
    }
}

module.exports = Cliente;

