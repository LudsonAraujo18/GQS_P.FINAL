describe('Dashboard - Testes E2E', () => {
  beforeEach(() => {
    // Visitar a página inicial
    cy.visit('/');
  });

  it('deve carregar o dashboard corretamente', () => {
    // Verificar se o título está correto
    cy.title().should('include', 'Sistema de Controle de Vendas e Clientes');
    
    // Verificar se o cabeçalho está presente
    cy.contains('h1', 'Dashboard').should('be.visible');
    
    // Verificar se os cards principais estão presentes
    cy.contains('Clientes').should('be.visible');
    cy.contains('Vendas').should('be.visible');
    
    // Verificar se a descrição do sistema está presente
    cy.contains('Bem-vindo ao Sistema de Controle de Vendas e Clientes').should('be.visible');
    cy.contains('Gestão da Qualidade de Software (GQS)').should('be.visible');
  });

  it('deve ter navegação funcional no menu', () => {
    // Verificar se todos os links do menu estão presentes
    cy.get('nav').within(() => {
      cy.contains('Dashboard').should('be.visible');
      cy.contains('Clientes').should('be.visible');
      cy.contains('Vendas').should('be.visible');
      cy.contains('Novo Cliente').should('be.visible');
      cy.contains('Nova Venda').should('be.visible');
    });
    
    // Testar navegação para Clientes
    cy.contains('nav a', 'Clientes').click();
    cy.url().should('include', '/clientes');
    cy.contains('h1', 'Lista de Clientes').should('be.visible');
    
    // Voltar ao dashboard
    cy.contains('nav a', 'Dashboard').click();
    cy.url().should('eq', Cypress.config().baseUrl + '/');
    
    // Testar navegação para Vendas
    cy.contains('nav a', 'Vendas').click();
    cy.url().should('include', '/vendas');
    cy.contains('h1', 'Lista de Vendas').should('be.visible');
    
    // Voltar ao dashboard
    cy.contains('nav a', 'Dashboard').click();
    cy.url().should('eq', Cypress.config().baseUrl + '/');
  });

  it('deve ter cards funcionais no dashboard', () => {
    // Testar card de Clientes
    cy.get('.dashboard-card').contains('Clientes').parent().within(() => {
      cy.contains('Gerencie seus clientes de forma eficiente').should('be.visible');
      
      // Testar botão "Ver Clientes"
      cy.contains('Ver Clientes').click();
    });
    
    cy.url().should('include', '/clientes');
    cy.go('back');
    
    // Testar card de Vendas
    cy.get('.dashboard-card').contains('Vendas').parent().within(() => {
      cy.contains('Controle todas as suas vendas').should('be.visible');
      
      // Testar botão "Ver Vendas"
      cy.contains('Ver Vendas').click();
    });
    
    cy.url().should('include', '/vendas');
    cy.go('back');
    
    // Testar botões de "Novo"
    cy.get('.dashboard-card').contains('Clientes').parent().within(() => {
      cy.contains('Novo Cliente').click();
    });
    
    cy.url().should('include', '/clientes/novo');
    cy.go('back');
    
    cy.get('.dashboard-card').contains('Vendas').parent().within(() => {
      cy.contains('Nova Venda').click();
    });
    
    cy.url().should('include', '/vendas/novo');
  });

  it('deve ter layout responsivo', () => {
    // Testar em viewport mobile
    cy.viewport(375, 667);
    
    // Verificar se o conteúdo ainda está visível
    cy.contains('h1', 'Dashboard').should('be.visible');
    cy.contains('Clientes').should('be.visible');
    cy.contains('Vendas').should('be.visible');
    
    // Verificar se a navegação está acessível
    cy.get('nav').should('be.visible');
    
    // Testar em viewport tablet
    cy.viewport(768, 1024);
    
    // Verificar se o layout se adapta
    cy.contains('h1', 'Dashboard').should('be.visible');
    cy.get('.dashboard-cards').should('be.visible');
    
    // Voltar ao viewport desktop
    cy.viewport(1280, 720);
    
    // Verificar se tudo ainda funciona
    cy.contains('h1', 'Dashboard').should('be.visible');
    cy.get('.dashboard-cards').should('be.visible');
  });

  it('deve ter footer presente', () => {
    // Rolar para baixo para ver o footer
    cy.scrollTo('bottom');
    
    // Verificar se o footer está presente
    cy.get('.footer').should('be.visible');
    cy.contains('2025 Sistema de Controle de Vendas e Clientes').should('be.visible');
    cy.contains('Projeto Final GQS').should('be.visible');
  });

  it('deve listar funcionalidades do sistema', () => {
    // Verificar se a seção de funcionalidades está presente
    cy.contains('Funcionalidades:').should('be.visible');
    
    // Verificar se todas as funcionalidades estão listadas
    cy.contains('Cadastro, edição e exclusão de clientes').should('be.visible');
    cy.contains('Cadastro, edição e exclusão de vendas').should('be.visible');
    cy.contains('Listagem e visualização de dados').should('be.visible');
    cy.contains('Interface responsiva e intuitiva').should('be.visible');
    cy.contains('API RESTful para integração').should('be.visible');
  });

  it('deve ter estilos CSS aplicados corretamente', () => {
    // Verificar se os estilos estão sendo aplicados
    cy.get('.header').should('have.css', 'background');
    cy.get('.dashboard-cards').should('be.visible');
    cy.get('.dashboard-card').should('have.css', 'background-color');
    
    // Verificar hover effects nos cards
    cy.get('.dashboard-card').first().trigger('mouseover');
    
    // Verificar se os botões têm estilos aplicados
    cy.get('.btn').should('have.css', 'padding');
    cy.get('.btn-primary').should('have.css', 'background');
  });

  it('deve carregar recursos estáticos corretamente', () => {
    // Verificar se o CSS está carregado
    cy.get('link[rel="stylesheet"]').should('exist');
    
    // Verificar se o JavaScript está carregado
    cy.get('script[src="/js/main.js"]').should('exist');
    
    // Verificar se a página carregou sem erros críticos
    cy.get('body').should('be.visible');
    cy.get('.header').should('be.visible');
  });
});

