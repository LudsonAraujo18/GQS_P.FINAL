describe('Cadastro de Cliente - Testes E2E', () => {
  beforeEach(() => {
    // Limpar banco de dados antes de cada teste
    cy.request('DELETE', '/api/clientes/999').then(() => {
      // Ignorar erro se cliente não existir
    });
    
    // Visitar a página inicial
    cy.visit('/');
  });

  it('deve acessar a página de cadastro de cliente', () => {
    // Clicar no link "Novo Cliente" no menu
    cy.contains('Novo Cliente').click();
    
    // Verificar se está na página correta
    cy.url().should('include', '/clientes/novo');
    cy.contains('h1', 'Novo Cliente').should('be.visible');
    
    // Verificar se os campos do formulário estão presentes
    cy.get('#nome').should('be.visible');
    cy.get('#email').should('be.visible');
    cy.get('#telefone').should('be.visible');
    cy.get('button[type="submit"]').should('contain', 'Cadastrar Cliente');
  });

  it('deve cadastrar um novo cliente com sucesso', () => {
    // Navegar para a página de cadastro
    cy.visit('/clientes/novo');
    
    // Preencher o formulário
    cy.get('#nome').type('João Silva');
    cy.get('#email').type('joao.silva@email.com');
    cy.get('#telefone').type('(11) 99999-9999');
    
    // Submeter o formulário
    cy.get('button[type="submit"]').click();
    
    // Verificar redirecionamento para lista de clientes
    cy.url().should('include', '/clientes');
    cy.url().should('include', 'success=Cliente%20cadastrado%20com%20sucesso');
    
    // Verificar se o cliente aparece na lista
    cy.contains('João Silva').should('be.visible');
    cy.contains('joao.silva@email.com').should('be.visible');
    cy.contains('(11) 99999-9999').should('be.visible');
    
    // Verificar mensagem de sucesso
    cy.get('.alert-success').should('contain', 'Cliente cadastrado com sucesso');
  });

  it('deve mostrar erros de validação quando campos obrigatórios estão vazios', () => {
    // Navegar para a página de cadastro
    cy.visit('/clientes/novo');
    
    // Tentar submeter formulário vazio
    cy.get('button[type="submit"]').click();
    
    // Verificar se ainda está na página de cadastro
    cy.url().should('include', '/clientes/novo');
    
    // Verificar se os campos obrigatórios têm validação HTML5
    cy.get('#nome:invalid').should('exist');
    cy.get('#email:invalid').should('exist');
  });

  it('deve mostrar erro quando email tem formato inválido', () => {
    // Navegar para a página de cadastro
    cy.visit('/clientes/novo');
    
    // Preencher com email inválido
    cy.get('#nome').type('João Silva');
    cy.get('#email').type('email-invalido');
    cy.get('#telefone').type('(11) 99999-9999');
    
    // Submeter o formulário
    cy.get('button[type="submit"]').click();
    
    // Verificar se ainda está na página de cadastro
    cy.url().should('include', '/clientes/novo');
    
    // Verificar se há erro de validação
    cy.get('.alert-danger, .error-list').should('be.visible');
  });

  it('deve navegar entre as páginas corretamente', () => {
    // Navegar para cadastro de cliente
    cy.visit('/clientes/novo');
    
    // Clicar em cancelar
    cy.contains('Cancelar').click();
    
    // Verificar redirecionamento para lista de clientes
    cy.url().should('include', '/clientes');
    cy.contains('h1', 'Lista de Clientes').should('be.visible');
    
    // Voltar para o dashboard
    cy.contains('Dashboard').click();
    cy.url().should('eq', Cypress.config().baseUrl + '/');
    cy.contains('h1', 'Dashboard').should('be.visible');
  });

  it('deve permitir editar um cliente existente', () => {
    // Primeiro, criar um cliente via API
    cy.request('POST', '/api/clientes', {
      nome: 'Maria Santos',
      email: 'maria@email.com',
      telefone: '(11) 88888-8888'
    }).then((response) => {
      const clienteId = response.body.id;
      
      // Visitar a lista de clientes
      cy.visit('/clientes');
      
      // Clicar no botão "Editar" do cliente criado
      cy.contains('tr', 'Maria Santos').within(() => {
        cy.contains('Editar').click();
      });
      
      // Verificar se está na página de edição
      cy.url().should('include', `/clientes/${clienteId}/editar`);
      cy.contains('h1', 'Editar Cliente').should('be.visible');
      
      // Verificar se os campos estão preenchidos
      cy.get('#nome').should('have.value', 'Maria Santos');
      cy.get('#email').should('have.value', 'maria@email.com');
      cy.get('#telefone').should('have.value', '(11) 88888-8888');
      
      // Editar os dados
      cy.get('#nome').clear().type('Maria Silva Santos');
      cy.get('#email').clear().type('maria.silva@email.com');
      
      // Submeter o formulário
      cy.get('button[type="submit"]').click();
      
      // Verificar redirecionamento e sucesso
      cy.url().should('include', '/clientes');
      cy.url().should('include', 'success=Cliente%20atualizado%20com%20sucesso');
      
      // Verificar se os dados foram atualizados na lista
      cy.contains('Maria Silva Santos').should('be.visible');
      cy.contains('maria.silva@email.com').should('be.visible');
    });
  });

  it('deve permitir visualizar detalhes de um cliente', () => {
    // Primeiro, criar um cliente via API
    cy.request('POST', '/api/clientes', {
      nome: 'Pedro Oliveira',
      email: 'pedro@email.com',
      telefone: '(11) 77777-7777'
    }).then((response) => {
      const clienteId = response.body.id;
      
      // Visitar a lista de clientes
      cy.visit('/clientes');
      
      // Clicar no botão "Ver" do cliente criado
      cy.contains('tr', 'Pedro Oliveira').within(() => {
        cy.contains('Ver').click();
      });
      
      // Verificar se está na página de detalhes
      cy.url().should('include', `/clientes/${clienteId}`);
      cy.contains('h1', 'Detalhes do Cliente').should('be.visible');
      
      // Verificar se as informações estão sendo exibidas
      cy.contains('Pedro Oliveira').should('be.visible');
      cy.contains('pedro@email.com').should('be.visible');
      cy.contains('(11) 77777-7777').should('be.visible');
      
      // Verificar botões de ação
      cy.contains('Editar').should('be.visible');
      cy.contains('Voltar à Lista').should('be.visible');
    });
  });

  it('deve permitir deletar um cliente', () => {
    // Primeiro, criar um cliente via API
    cy.request('POST', '/api/clientes', {
      nome: 'Cliente Para Deletar',
      email: 'deletar@email.com',
      telefone: '(11) 66666-6666'
    }).then(() => {
      // Visitar a lista de clientes
      cy.visit('/clientes');
      
      // Verificar se o cliente está na lista
      cy.contains('Cliente Para Deletar').should('be.visible');
      
      // Clicar no botão "Deletar" do cliente criado
      cy.contains('tr', 'Cliente Para Deletar').within(() => {
        cy.get('button').contains('Deletar').click();
      });
      
      // Verificar redirecionamento e sucesso
      cy.url().should('include', '/clientes');
      cy.url().should('include', 'success=Cliente%20deletado%20com%20sucesso');
      
      // Verificar se o cliente foi removido da lista
      cy.contains('Cliente Para Deletar').should('not.exist');
    });
  });
});

