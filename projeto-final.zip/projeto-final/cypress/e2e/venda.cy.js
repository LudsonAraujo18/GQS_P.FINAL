describe('Cadastro de Venda - Testes E2E', () => {
  let clienteId;

  beforeEach(() => {
    // Limpar banco de dados e criar um cliente para usar nos testes
    cy.request('DELETE', '/api/vendas/999').then(() => {
      // Ignorar erro se venda não existir
    });
    
    cy.request('DELETE', '/api/clientes/999').then(() => {
      // Ignorar erro se cliente não existir
    });

    // Criar um cliente para usar nos testes de venda
    cy.request('POST', '/api/clientes', {
      nome: 'Cliente Teste',
      email: 'cliente.teste@email.com',
      telefone: '(11) 99999-9999'
    }).then((response) => {
      clienteId = response.body.id;
    });
    
    // Visitar a página inicial
    cy.visit('/');
  });

  it('deve acessar a página de cadastro de venda', () => {
    // Clicar no link "Nova Venda" no menu
    cy.contains('Nova Venda').click();
    
    // Verificar se está na página correta
    cy.url().should('include', '/vendas/novo');
    cy.contains('h1', 'Nova Venda').should('be.visible');
    
    // Verificar se os campos do formulário estão presentes
    cy.get('#cliente_id').should('be.visible');
    cy.get('#data_venda').should('be.visible');
    cy.get('#valor_total').should('be.visible');
    cy.get('#descricao').should('be.visible');
    cy.get('button[type="submit"]').should('contain', 'Cadastrar Venda');
  });

  it('deve cadastrar uma nova venda com sucesso', () => {
    // Navegar para a página de cadastro
    cy.visit('/vendas/novo');
    
    // Preencher o formulário
    cy.get('#cliente_id').select('Cliente Teste - cliente.teste@email.com');
    cy.get('#data_venda').type('2025-07-20');
    cy.get('#valor_total').type('150.50');
    cy.get('#descricao').type('Venda de produtos diversos');
    
    // Submeter o formulário
    cy.get('button[type="submit"]').click();
    
    // Verificar redirecionamento para lista de vendas
    cy.url().should('include', '/vendas');
    cy.url().should('include', 'success=Venda%20cadastrada%20com%20sucesso');
    
    // Verificar se a venda aparece na lista
    cy.contains('Cliente Teste').should('be.visible');
    cy.contains('R$ 150,50').should('be.visible');
    cy.contains('Venda de produtos diversos').should('be.visible');
    
    // Verificar mensagem de sucesso
    cy.get('.alert-success').should('contain', 'Venda cadastrada com sucesso');
  });

  it('deve mostrar erros de validação quando campos obrigatórios estão vazios', () => {
    // Navegar para a página de cadastro
    cy.visit('/vendas/novo');
    
    // Tentar submeter formulário vazio
    cy.get('button[type="submit"]').click();
    
    // Verificar se ainda está na página de cadastro
    cy.url().should('include', '/vendas/novo');
    
    // Verificar se os campos obrigatórios têm validação HTML5
    cy.get('#cliente_id:invalid').should('exist');
    cy.get('#data_venda:invalid').should('exist');
    cy.get('#valor_total:invalid').should('exist');
  });

  it('deve mostrar erro quando valor total é inválido', () => {
    // Navegar para a página de cadastro
    cy.visit('/vendas/novo');
    
    // Preencher com valor inválido
    cy.get('#cliente_id').select('Cliente Teste - cliente.teste@email.com');
    cy.get('#data_venda').type('2025-07-20');
    cy.get('#valor_total').type('0');
    cy.get('#descricao').type('Teste');
    
    // Submeter o formulário
    cy.get('button[type="submit"]').click();
    
    // Verificar se ainda está na página de cadastro
    cy.url().should('include', '/vendas/novo');
    
    // Verificar se há erro de validação
    cy.get('.alert-danger, .error-list').should('be.visible');
  });

  it('deve navegar entre as páginas corretamente', () => {
    // Navegar para cadastro de venda
    cy.visit('/vendas/novo');
    
    // Clicar em cancelar
    cy.contains('Cancelar').click();
    
    // Verificar redirecionamento para lista de vendas
    cy.url().should('include', '/vendas');
    cy.contains('h1', 'Lista de Vendas').should('be.visible');
    
    // Voltar para o dashboard
    cy.contains('Dashboard').click();
    cy.url().should('eq', Cypress.config().baseUrl + '/');
    cy.contains('h1', 'Dashboard').should('be.visible');
  });

  it('deve permitir editar uma venda existente', () => {
    // Primeiro, criar uma venda via API
    cy.request('POST', '/api/vendas', {
      cliente_id: clienteId,
      data_venda: '2025-07-20',
      valor_total: 100.00,
      descricao: 'Venda original'
    }).then((response) => {
      const vendaId = response.body.id;
      
      // Visitar a lista de vendas
      cy.visit('/vendas');
      
      // Clicar no botão "Editar" da venda criada
      cy.contains('tr', 'Cliente Teste').within(() => {
        cy.contains('Editar').click();
      });
      
      // Verificar se está na página de edição
      cy.url().should('include', `/vendas/${vendaId}/editar`);
      cy.contains('h1', 'Editar Venda').should('be.visible');
      
      // Verificar se os campos estão preenchidos
      cy.get('#cliente_id').should('have.value', clienteId.toString());
      cy.get('#data_venda').should('have.value', '2025-07-20');
      cy.get('#valor_total').should('have.value', '100');
      cy.get('#descricao').should('have.value', 'Venda original');
      
      // Editar os dados
      cy.get('#valor_total').clear().type('200.00');
      cy.get('#descricao').clear().type('Venda atualizada');
      
      // Submeter o formulário
      cy.get('button[type="submit"]').click();
      
      // Verificar redirecionamento e sucesso
      cy.url().should('include', '/vendas');
      cy.url().should('include', 'success=Venda%20atualizada%20com%20sucesso');
      
      // Verificar se os dados foram atualizados na lista
      cy.contains('R$ 200,00').should('be.visible');
      cy.contains('Venda atualizada').should('be.visible');
    });
  });

  it('deve permitir visualizar detalhes de uma venda', () => {
    // Primeiro, criar uma venda via API
    cy.request('POST', '/api/vendas', {
      cliente_id: clienteId,
      data_venda: '2025-07-20',
      valor_total: 300.00,
      descricao: 'Venda para visualizar'
    }).then((response) => {
      const vendaId = response.body.id;
      
      // Visitar a lista de vendas
      cy.visit('/vendas');
      
      // Clicar no botão "Ver" da venda criada
      cy.contains('tr', 'Cliente Teste').within(() => {
        cy.contains('Ver').click();
      });
      
      // Verificar se está na página de detalhes
      cy.url().should('include', `/vendas/${vendaId}`);
      cy.contains('h1', 'Detalhes da Venda').should('be.visible');
      
      // Verificar se as informações estão sendo exibidas
      cy.contains('Cliente Teste').should('be.visible');
      cy.contains('cliente.teste@email.com').should('be.visible');
      cy.contains('R$ 300,00').should('be.visible');
      cy.contains('Venda para visualizar').should('be.visible');
      
      // Verificar botões de ação
      cy.contains('Editar').should('be.visible');
      cy.contains('Voltar à Lista').should('be.visible');
    });
  });

  it('deve permitir deletar uma venda', () => {
    // Primeiro, criar uma venda via API
    cy.request('POST', '/api/vendas', {
      cliente_id: clienteId,
      data_venda: '2025-07-20',
      valor_total: 50.00,
      descricao: 'Venda para deletar'
    }).then(() => {
      // Visitar a lista de vendas
      cy.visit('/vendas');
      
      // Verificar se a venda está na lista
      cy.contains('Venda para deletar').should('be.visible');
      
      // Clicar no botão "Deletar" da venda criada
      cy.contains('tr', 'Venda para deletar').within(() => {
        cy.get('button').contains('Deletar').click();
      });
      
      // Verificar redirecionamento e sucesso
      cy.url().should('include', '/vendas');
      cy.url().should('include', 'success=Venda%20deletada%20com%20sucesso');
      
      // Verificar se a venda foi removida da lista
      cy.contains('Venda para deletar').should('not.exist');
    });
  });

  it('deve mostrar mensagem quando não há clientes cadastrados', () => {
    // Deletar todos os clientes
    cy.request('DELETE', `/api/clientes/${clienteId}`);
    
    // Navegar para a página de cadastro de venda
    cy.visit('/vendas/novo');
    
    // Verificar se há mensagem informando sobre a necessidade de cadastrar clientes
    cy.get('.alert-info').should('contain', 'Não há clientes cadastrados');
    cy.contains('Cadastrar Cliente').should('be.visible');
  });

  it('deve integrar corretamente com o dashboard', () => {
    // Visitar o dashboard
    cy.visit('/');
    
    // Verificar se os cards estão presentes
    cy.contains('Clientes').should('be.visible');
    cy.contains('Vendas').should('be.visible');
    
    // Clicar no card de vendas
    cy.contains('Ver Vendas').click();
    
    // Verificar redirecionamento
    cy.url().should('include', '/vendas');
    cy.contains('h1', 'Lista de Vendas').should('be.visible');
    
    // Voltar ao dashboard e testar o botão "Nova Venda"
    cy.visit('/');
    cy.contains('Nova Venda').click();
    
    // Verificar redirecionamento
    cy.url().should('include', '/vendas/novo');
    cy.contains('h1', 'Nova Venda').should('be.visible');
  });
});

