const express = require('express');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const path = require('path');
const database = require('./src/database/database');

// Importar rotas
const clienteRoutes = require('./src/routes/clienteRoutes');
const vendaRoutes = require('./src/routes/vendaRoutes');
const indexRoutes = require('./src/routes/index');
const apiRoutes = require('./src/routes/apiRoutes');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuração do EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src/views'));

// Middlewares
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'src/public')));

// Inicializar banco de dados
database.init();

// Rotas
app.use('/', indexRoutes);
app.use('/clientes', clienteRoutes);
app.use('/vendas', vendaRoutes);
app.use('/api', apiRoutes);

// Middleware de tratamento de erro 404
app.use((req, res) => {
    res.status(404).render('partials/404', { title: 'Página não encontrada' });
});

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('partials/error', { 
        title: 'Erro interno do servidor',
        error: err.message 
    });
});

// Iniciar servidor
if (require.main === module) {
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`Servidor rodando na porta ${PORT}`);
        console.log(`Acesse: http://localhost:${PORT}`);
    });
}

module.exports = app;

